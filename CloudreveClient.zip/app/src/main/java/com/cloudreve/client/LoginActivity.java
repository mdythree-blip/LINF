package com.cloudreve.client;

import android.content.Intent;
import android.net.Uri;
import android.os.AsyncTask;
import android.os.Bundle;
import android.util.Log;
import android.view.View;
import android.widget.Button;
import android.widget.EditText;
import android.widget.Toast;

import androidx.appcompat.app.AppCompatActivity;

import java.io.UnsupportedEncodingException;
import java.security.NoSuchAlgorithmException;
import java.util.UUID;

public class LoginActivity extends AppCompatActivity {

    private static final String TAG = "LoginActivity";
    private static final String REDIRECT_URI = "cloudreveclient://callback";
    private static final String SCOPE = "openid profile offline_access Files.Read"; // Request offline_access for refresh token

    private EditText etServerUrl;
    private EditText etClientId;
    private EditText etClientSecret;
    private Button btnLogin;

    private AuthManager authManager;

    // User-provided credentials
    private static final String CLOUDREVE_SERVER_URL = "https://pan.linfshare.top";
    private static final String CLIENT_ID = "721f0caa-b6ed-4d67-b82b-a4ffd392a4d7";
    private static final String CLIENT_SECRET = "hbNPKLTyhNjQCQYID5r6UWO3CqmpryIq";

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_login);

        authManager = new AuthManager(this);

        etServerUrl = findViewById(R.id.et_server_url);
        etClientId = findViewById(R.id.et_client_id);
        etClientSecret = findViewById(R.id.et_client_secret);
        btnLogin = findViewById(R.id.btn_login);

        // Pre-fill with user-provided values
        etServerUrl.setText(CLOUDREVE_SERVER_URL);
        etClientId.setText(CLIENT_ID);
        etClientSecret.setText(CLIENT_SECRET);

        btnLogin.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                String serverUrl = etServerUrl.getText().toString().trim();
                String clientId = etClientId.getText().toString().trim();
                String clientSecret = etClientSecret.getText().toString().trim();

                if (serverUrl.isEmpty() || clientId.isEmpty() || clientSecret.isEmpty()) {
                    Toast.makeText(LoginActivity.this, "请填写所有信息", Toast.LENGTH_SHORT).show();
                    return;
                }

                authManager.saveServerConfig(serverUrl, clientId, clientSecret);
                startOAuthFlow();
            }
        });

        // Check if already logged in
        if (authManager.isLoggedIn()) {
            startMainActivity();
        }
    }

    private void startOAuthFlow() {
        try {
            String codeVerifier = PKCEUtil.generateCodeVerifier();
            String codeChallenge = PKCEUtil.generateCodeChallenge(codeVerifier);
            authManager.saveCodeVerifier(codeVerifier);

            String state = UUID.randomUUID().toString(); // For CSRF protection

            Uri.Builder builder = Uri.parse(authManager.getServerUrl() + "/session/authorize").buildUpon()
                    .appendQueryParameter("response_type", "code")
                    .appendQueryParameter("client_id", authManager.getClientId())
                    .appendQueryParameter("redirect_uri", REDIRECT_URI)
                    .appendQueryParameter("scope", SCOPE)
                    .appendQueryParameter("state", state)
                    .appendQueryParameter("code_challenge", codeChallenge)
                    .appendQueryParameter("code_challenge_method", "S256");

            Intent intent = new Intent(Intent.ACTION_VIEW, builder.build());
            startActivity(intent);

        } catch (UnsupportedEncodingException | NoSuchAlgorithmException e) {
            Log.e(TAG, "Error generating PKCE parameters", e);
            Toast.makeText(this, "登录失败: " + e.getMessage(), Toast.LENGTH_LONG).show();
        }
    }

    @Override
    protected void onResume() {
        super.onResume();
        // Check for OAuth redirect after returning from browser
        Uri uri = getIntent().getData();
        if (uri != null && uri.toString().startsWith(REDIRECT_URI)) {
            String code = uri.getQueryParameter("code");
            String state = uri.getQueryParameter("state"); // TODO: Verify state

            if (code != null) {
                Log.d(TAG, "Authorization code received: " + code);
                new ExchangeTokenTask().execute(code);
            } else {
                String error = uri.getQueryParameter("error");
                Log.e(TAG, "OAuth error: " + error);
                Toast.makeText(this, "OAuth 授权失败: " + error, Toast.LENGTH_LONG).show();
            }
            // Clear the intent data to prevent re-processing on subsequent onResume calls
            getIntent().setData(null);
        }
    }

    private void startMainActivity() {
        Intent intent = new Intent(LoginActivity.this, MainActivity.class);
        startActivity(intent);
        finish();
    }

    private class ExchangeTokenTask extends AsyncTask<String, Void, TokenResponse> {
        private String errorMessage;

        @Override
        protected TokenResponse doInBackground(String... codes) {
            String code = codes[0];
            String codeVerifier = authManager.getCodeVerifier();
            if (codeVerifier == null) {
                errorMessage = "Code Verifier not found.";
                return null;
            }
            ApiClient apiClient = new ApiClient(authManager);
            try {
                return apiClient.exchangeToken(code, codeVerifier);
            } catch (Exception e) {
                errorMessage = e.getMessage();
                Log.e(TAG, "Token exchange failed", e);
                return null;
            }
        }

        @Override
        protected void onPostExecute(TokenResponse tokenResponse) {
            if (tokenResponse != null) {
                Toast.makeText(LoginActivity.this, "登录成功！", Toast.LENGTH_SHORT).show();
                startMainActivity();
            } else {
                Toast.makeText(LoginActivity.this, "登录失败: " + errorMessage, Toast.LENGTH_LONG).show();
            }
        }
    }
}
