package com.cloudreve.client;

import android.app.ProgressDialog;
import android.content.Intent;
import android.net.Uri;
import android.os.AsyncTask;
import android.os.Bundle;
import android.os.Environment;
import android.util.Log;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.ImageView;
import android.widget.TextView;
import android.widget.Toast;

import androidx.annotation.NonNull;
import androidx.appcompat.app.AppCompatActivity;
import androidx.recyclerview.widget.LinearLayoutManager;
import androidx.recyclerview.widget.RecyclerView;

import java.io.File;
import java.io.FileOutputStream;
import java.io.InputStream;
import java.net.HttpURLConnection;
import java.net.URL;
import java.text.DecimalFormat;
import java.util.ArrayList;
import java.util.List;

public class MainActivity extends AppCompatActivity {

    private static final String TAG = "MainActivity";
    private RecyclerView rvFileList;
    private FileAdapter fileAdapter;
    private List<CloudreveFile> currentFiles;
    private AuthManager authManager;
    private ApiClient apiClient;
    private String currentPath = "/";

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);

        authManager = new AuthManager(this);
        apiClient = new ApiClient(authManager);
        currentFiles = new ArrayList<>();

        rvFileList = findViewById(R.id.rv_file_list);
        rvFileList.setLayoutManager(new LinearLayoutManager(this));
        fileAdapter = new FileAdapter(currentFiles);
        rvFileList.setAdapter(fileAdapter);

        fileAdapter.setOnItemClickListener(new FileAdapter.OnItemClickListener() {
            @Override
            public void onItemClick(CloudreveFile file) {
                if (file.isDirectory()) {
                    currentPath = file.getPath() + file.getName() + "/";
                    new FetchFilesTask().execute(currentPath);
                } else {
                    new DownloadFileTask().execute(file);
                }
            }
        });

        new FetchFilesTask().execute(currentPath);
    }

    @Override
    public void onBackPressed() {
        if (!currentPath.equals("/")) {
            // Go up one directory
            int lastSlash = currentPath.substring(0, currentPath.length() - 1).lastIndexOf('/');
            if (lastSlash != -1) {
                currentPath = currentPath.substring(0, lastSlash + 1);
            } else {
                currentPath = "/";
            }
            new FetchFilesTask().execute(currentPath);
        } else {
            super.onBackPressed();
        }
    }

    private class FetchFilesTask extends AsyncTask<String, Void, ApiClient.DirectoryResponse> {
        private String errorMessage;
        private ProgressDialog progressDialog;

        @Override
        protected void onPreExecute() {
            super.onPreExecute();
            progressDialog = new ProgressDialog(MainActivity.this);
            progressDialog.setMessage("加载中...");
            progressDialog.setCancelable(false);
            progressDialog.show();
        }

        @Override
        protected ApiClient.DirectoryResponse doInBackground(String... paths) {
            try {
                ApiResponse<ApiClient.DirectoryResponse> response = apiClient.getFileList(paths[0]);
                if (response.isSuccess()) {
                    return response.getData();
                } else {
                    errorMessage = response.getMsg();
                    return null;
                }
            } catch (Exception e) {
                errorMessage = e.getMessage();
                Log.e(TAG, "Error fetching file list", e);
                return null;
            }
        }

        @Override
        protected void onPostExecute(ApiClient.DirectoryResponse directoryResponse) {
            progressDialog.dismiss();
            if (directoryResponse != null) {
                currentFiles.clear();
                currentFiles.addAll(directoryResponse.objects);
                fileAdapter.notifyDataSetChanged();
                setTitle(currentPath.equals("/") ? "我的文件" : currentPath);
            } else {
                Toast.makeText(MainActivity.this, "加载文件失败: " + errorMessage, Toast.LENGTH_LONG).show();
                if (errorMessage != null && errorMessage.contains("token")) {
                    // Token expired or invalid, go back to login
                    authManager.clearAuthData();
                    Intent intent = new Intent(MainActivity.this, LoginActivity.class);
                    startActivity(intent);
                    finish();
                }
            }
        }
    }

    private class DownloadFileTask extends AsyncTask<CloudreveFile, Integer, String> {
        private ProgressDialog progressDialog;
        private CloudreveFile fileToDownload;

        @Override
        protected void onPreExecute() {
            super.onPreExecute();
            progressDialog = new ProgressDialog(MainActivity.this);
            progressDialog.setMessage("下载中...");
            progressDialog.setProgressStyle(ProgressDialog.STYLE_HORIZONTAL);
            progressDialog.setCancelable(false);
            progressDialog.show();
        }

        @Override
        protected String doInBackground(CloudreveFile... files) {
            fileToDownload = files[0];
            try {
                ApiResponse<ApiClient.DownloadResponse> response = apiClient.getDownloadUrl(fileToDownload.getId());
                if (response.isSuccess() && response.getData() != null) {
                    String downloadUrl = response.getData().url;
                    return downloadFile(downloadUrl, fileToDownload.getName());
                } else {
                    return "获取下载链接失败: " + response.getMsg();
                }
            } catch (Exception e) {
                Log.e(TAG, "Error getting download URL", e);
                return "获取下载链接失败: " + e.getMessage();
            }
        }

        private String downloadFile(String downloadUrl, String fileName) {
            try {
                URL url = new URL(downloadUrl);
                HttpURLConnection connection = (HttpURLConnection) url.openConnection();
                connection.connect();

                if (connection.getResponseCode() != HttpURLConnection.HTTP_OK) {
                    return "服务器返回错误: " + connection.getResponseCode();
                }

                int fileLength = connection.getContentLength();

                File outputDir = Environment.getExternalStoragePublicDirectory(Environment.DIRECTORY_DOWNLOADS);
                if (!outputDir.exists()) {
                    outputDir.mkdirs();
                }
                File outputFile = new File(outputDir, fileName);
                FileOutputStream fos = new FileOutputStream(outputFile);
                InputStream is = connection.getInputStream();

                byte[] buffer = new byte[4096];
                int len1;
                long total = 0;
                while ((len1 = is.read(buffer)) != -1) {
                    total += len1;
                    if (fileLength > 0) {
                        publishProgress((int) (total * 100 / fileLength));
                    }
                    fos.write(buffer, 0, len1);
                }
                fos.close();
                is.close();
                return "文件下载成功: " + outputFile.getAbsolutePath();

            } catch (Exception e) {
                Log.e(TAG, "Error downloading file", e);
                return "文件下载失败: " + e.getMessage();
            }
        }

        @Override
        protected void onProgressUpdate(Integer... values) {
            super.onProgressUpdate(values);
            progressDialog.setProgress(values[0]);
        }

        @Override
        protected void onPostExecute(String result) {
            progressDialog.dismiss();
            Toast.makeText(MainActivity.this, result, Toast.LENGTH_LONG).show();
            if (result.startsWith("文件下载成功")) {
                // Optionally, open the downloaded file
                Intent intent = new Intent(Intent.ACTION_VIEW);
                Uri fileUri = Uri.parse(result.substring(result.indexOf(":") + 2));
                intent.setDataAndType(fileUri, getMimeType(fileToDownload.getName()));
                intent.addFlags(Intent.FLAG_GRANT_READ_URI_PERMISSION);
                try {
                    startActivity(intent);
                } catch (Exception e) {
                    Toast.makeText(MainActivity.this, "无法打开文件，请安装相应的应用", Toast.LENGTH_SHORT).show();
                }
            }
        }

        private String getMimeType(String fileName) {
            String type = null;
            String extension = android.webkit.MimeTypeMap.getFileExtensionFromUrl(fileName);
            if (extension != null) {
                type = android.webkit.MimeTypeMap.getSingleton().getMimeTypeFromExtension(extension);
            }
            return type;
        }
    }

    // Helper for file size formatting
    public static String formatFileSize(long size) {
        if (size <= 0) return "0 B";
        final String[] units = new String[]{"B", "KB", "MB", "GB", "TB"};
        int digitGroups = (int) (Math.log10(size) / Math.log10(1024));
        return new DecimalFormat("#,##0.#").format(size / Math.pow(1024, digitGroups)) + " " + units[digitGroups];
    }
}
