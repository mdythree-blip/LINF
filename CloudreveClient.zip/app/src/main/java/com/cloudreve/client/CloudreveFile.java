package com.cloudreve.client;

import com.google.gson.annotations.SerializedName;

public class CloudreveFile {
    @SerializedName("id")
    private String id;
    @SerializedName("name")
    private String name;
    @SerializedName("path")
    private String path;
    @SerializedName("type")
    private String type; // "dir" or "file"
    @SerializedName("size")
    private long size;
    @SerializedName("date")
    private String date;

    public String getId() {
        return id;
    }

    public String getName() {
        return name;
    }

    public String getPath() {
        return path;
    }

    public String getType() {
        return type;
    }

    public long getSize() {
        return size;
    }

    public String getDate() {
        return date;
    }

    public boolean isDirectory() {
        return "dir".equals(type);
    }
}
