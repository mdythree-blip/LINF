package com.cloudreve.client;

import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.ImageView;
import android.widget.TextView;

import androidx.annotation.NonNull;
import androidx.recyclerview.widget.RecyclerView;

import java.util.List;

public class FileAdapter extends RecyclerView.Adapter<FileAdapter.FileViewHolder> {

    private List<CloudreveFile> fileList;
    private OnItemClickListener listener;

    public interface OnItemClickListener {
        void onItemClick(CloudreveFile file);
    }

    public void setOnItemClickListener(OnItemClickListener listener) {
        this.listener = listener;
    }

    public FileAdapter(List<CloudreveFile> fileList) {
        this.fileList = fileList;
    }

    @NonNull
    @Override
    public FileViewHolder onCreateViewHolder(@NonNull ViewGroup parent, int viewType) {
        View view = LayoutInflater.from(parent.getContext()).inflate(R.layout.item_file, parent, false);
        return new FileViewHolder(view);
    }

    @Override
    public void onBindViewHolder(@NonNull FileViewHolder holder, int position) {
        CloudreveFile file = fileList.get(position);
        holder.tvFileName.setText(file.getName());

        if (file.isDirectory()) {
            holder.ivFileIcon.setImageResource(R.drawable.ic_folder);
            holder.tvFileSizeDate.setText("文件夹");
        } else {
            holder.ivFileIcon.setImageResource(R.drawable.ic_file);
            holder.tvFileSizeDate.setText(MainActivity.formatFileSize(file.getSize()) + " | " + file.getDate().substring(0, 10)); // Display date part only
        }

        holder.itemView.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                if (listener != null) {
                    listener.onItemClick(file);
                }
            }
        });
    }

    @Override
    public int getItemCount() {
        return fileList.size();
    }

    public static class FileViewHolder extends RecyclerView.ViewHolder {
        ImageView ivFileIcon;
        TextView tvFileName;
        TextView tvFileSizeDate;

        public FileViewHolder(@NonNull View itemView) {
            super(itemView);
            ivFileIcon = itemView.findViewById(R.id.iv_file_icon);
            tvFileName = itemView.findViewById(R.id.tv_file_name);
            tvFileSizeDate = itemView.findViewById(R.id.tv_file_size_date);
        }
    }
}
