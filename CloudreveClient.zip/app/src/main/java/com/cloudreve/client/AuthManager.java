package com.cloudreve.client;

import android.content.Context;
import android.content.SharedPreferences;

public class AuthManager {
    private static final String PREF_NAME = "CloudreveAuth";
    private static final String KEY_ACCESS_TOKEN = "access_token";
    private static final String KEY_REFRESH_TOKEN = "refresh_token";
    private static final String KEY_ACCESS_EXPIRES_IN = "access_expires_in";
    private static final String KEY_REFRESH_EXPIRES_IN = "refresh_expires_in";
    private static final String KEY_CODE_VERIFIER = "code_verifier";
    private static final String KEY_SERVER_URL = "server_url";
    private static final String KEY_CLIENT_ID = "client_id";
    private static final String KEY_CLIENT_SECRET = "client_secret";

    private SharedPreferences sharedPreferences;

    public AuthManager(Context context) {
        sharedPreferences = context.getSharedPreferences(PREF_NAME, Context.MODE_PRIVATE);
    }

    public void saveAuthData(String accessToken, String refreshToken, long accessExpiresIn, long refreshExpiresIn) {
        SharedPreferences.Editor editor = sharedPreferences.edit();
        editor.putString(KEY_ACCESS_TOKEN, accessToken);
        editor.putString(KEY_REFRESH_TOKEN, refreshToken);
        editor.putLong(KEY_ACCESS_EXPIRES_IN, System.currentTimeMillis() / 1000 + accessExpiresIn);
        editor.putLong(KEY_REFRESH_EXPIRES_IN, System.currentTimeMillis() / 1000 + refreshExpiresIn);
        editor.apply();
    }

    public void saveCodeVerifier(String codeVerifier) {
        SharedPreferences.Editor editor = sharedPreferences.edit();
        editor.putString(KEY_CODE_VERIFIER, codeVerifier);
        editor.apply();
    }

    public String getCodeVerifier() {
        return sharedPreferences.getString(KEY_CODE_VERIFIER, null);
    }

    public String getAccessToken() {
        return sharedPreferences.getString(KEY_ACCESS_TOKEN, null);
    }

    public String getRefreshToken() {
        return sharedPreferences.getString(KEY_REFRESH_TOKEN, null);
    }

    public long getAccessExpiresIn() {
        return sharedPreferences.getLong(KEY_ACCESS_EXPIRES_IN, 0);
    }

    public long getRefreshExpiresIn() {
        return sharedPreferences.getLong(KEY_REFRESH_EXPIRES_IN, 0);
    }

    public boolean isAccessTokenExpired() {
        return System.currentTimeMillis() / 1000 >= getAccessExpiresIn();
    }

    public boolean isRefreshTokenExpired() {
        return System.currentTimeMillis() / 1000 >= getRefreshExpiresIn();
    }

    public void clearAuthData() {
        SharedPreferences.Editor editor = sharedPreferences.edit();
        editor.remove(KEY_ACCESS_TOKEN);
        editor.remove(KEY_REFRESH_TOKEN);
        editor.remove(KEY_ACCESS_EXPIRES_IN);
        editor.remove(KEY_REFRESH_EXPIRES_IN);
        editor.remove(KEY_CODE_VERIFIER);
        editor.apply();
    }

    public void saveServerConfig(String serverUrl, String clientId, String clientSecret) {
        SharedPreferences.Editor editor = sharedPreferences.edit();
        editor.putString(KEY_SERVER_URL, serverUrl);
        editor.putString(KEY_CLIENT_ID, clientId);
        editor.putString(KEY_CLIENT_SECRET, clientSecret);
        editor.apply();
    }

    public String getServerUrl() {
        return sharedPreferences.getString(KEY_SERVER_URL, null);
    }

    public String getClientId() {
        return sharedPreferences.getString(KEY_CLIENT_ID, null);
    }

    public String getClientSecret() {
        return sharedPreferences.getString(KEY_CLIENT_SECRET, null);
    }

    public boolean isLoggedIn() {
        return getAccessToken() != null && !isAccessTokenExpired();
    }
}
